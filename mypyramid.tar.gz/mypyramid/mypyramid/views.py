from pyramid.view import view_config
import logging
from pyramid.response import Response
from .models import (
    DBSession,
    MyModel,
    )
from pyramid.httpexceptions import HTTPCreated, HTTPNotAcceptable


@view_config(route_name='home', renderer='templates/mytemplate.pt')
def my_view(request):
    one = DBSession.query(MyModel).filter(MyModel.name=='one').first()
    return {'one':one, 'project':'mypyramid'}
    
# using eval, oppsite to repr
def requestinfo(req):
    target = """
        method,
        url,
        params,
        path_url,
        host_url,
        path_qs
    """
    res = ""
    for i in target.split(','):
        s = 'req.' + i.strip()
        tmp = "%s:	" %s +'%s\n'
        tmp =tmp %eval(s)
        res += tmp 
    return res
    
@view_config(route_name='hello', renderer = 'string', 
request_method='POST',
http_cache= (1, {'public':False}),
request_param="foo=123",
match_param="id=4",
permission = 'login',
)
#curl localhost:6543/hello/4 -d 'foo=123'
def hello(request):
    return requestinfo(request)

@view_config(route_name='num', renderer='json')
@view_config(route_name='string', renderer='json')
def multiple(request):
    #return HTTPCreated()
    raise HTTPNotAcceptable()
    return {'data':'OK'}

@view_config(route_name='use_session', renderer='json', permission='edit')
def use_session(request):
    session = request.session
    logging.info(session)
    if 'abc' in session:
        session['fred'] = 'yes'
    session['abc'] = '123'
    if 'fred' in session:
        return Response('Fred was in the session')
    else:
        return Response('Fred was not in the session')

@view_config(route_name='test_csrf', renderer='json')
def test_csrf(request):
    logging.info(requestinfo(request))
    csrf_token = request.session.get_csrf_token()
    logging.info('csrf_token:    %s', csrf_token)
    if request.method == 'POST':
        logging.info(request.POST['csrf_token'])
        if csrf_token != request.POST['csrf_token']:
            raise ValueError('CSRF token did not match')
    # Refresh csrf_token once used it
    csrf_token = request.session.new_csrf_token()
    return csrf_token


