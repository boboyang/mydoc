from pyramid.security import remember
from pyramid.security import forget
import logging

#use dummy data instead of getting from DB
USERS = {'editor':'editor',
         'viewer':'viewer'}
GROUPS = {'editor':['group:editors']}

def groupfinder(userid, request):
    if userid in USERS:
        return GROUPS.get(userid, [])

def login(request):
    logging.info('login')
    headers = remember(request, 'user')
    return headers

def logout(request):
    headers = forget(request)
    return headers
