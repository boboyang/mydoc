from pyramid.paster import bootstrap
import logging.config
logging.config.fileConfig('development.ini')


env = bootstrap('development.ini')
print env['request'].route_url('home')
print env['request'].route_url('hello', id='4')

env['request'].host = 'example.com'
env['request'].scheme = 'https'
env['request'].script_name = '/prefix'
print env['request'].application_url

#end
env['closer']()

