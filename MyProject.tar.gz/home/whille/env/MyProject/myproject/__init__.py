from pyramid.config import Configurator
from sqlalchemy import engine_from_config
from pyramid.view import append_slash_notfound_view
from pyramid.httpexceptions import HTTPNotFound
from .models import DBSession
from pyramid_beaker import session_factory_from_settings, set_cache_regions_from_settings


def main(global_config, **settings):
    """ This function returns a Pyramid WSGI application.
    """
    engine = engine_from_config(settings, 'sqlalchemy.')
    DBSession.configure(bind=engine)

    my_session_factory = session_factory_from_settings(settings)
    set_cache_regions_from_settings(settings)

    config = Configurator(settings=settings,
                          session_factory = my_session_factory)
    config.add_static_view('static', 'static', cache_max_age=3600)
    config.add_route('home', '/')
    config.add_route('hello','hello/{id}')
    config.add_route('num','num')
    config.add_route('string','string')
    config.add_route('use_session','use_session')
    config.add_route('test_csrf','test_csrf')
    
    config.scan()
#    config.add_view(append_slash_notfound_view, context=HTTPNotFound)
    return config.make_wsgi_app()

